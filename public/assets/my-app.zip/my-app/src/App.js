import './App.css';
import CardComponent from './components/CardComponent';
import CarouselView from './components/carouselView';
import DetailCard from './components/detailCard'
function App() {
  return (
    <div className="App">
      <div className='row m-4'>
        <div className='col-lg-8 col-md-8 col-sm-12'>
        <CarouselView/>
        <DetailCard/>
        <CardComponent></CardComponent>
        </div>
        <div className='col-lg-4 col-md-4 col-sm-12'>
          biker
        </div>
      </div>
      
    </div>
  );
}

export default App;
