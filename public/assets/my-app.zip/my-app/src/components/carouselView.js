import React, { useState } from "react";
import "./carouselView.css";
const CarouselView = () => {
  const Images = [
    {
      id: 0,
      url: "https://www.greenbiz.com/sites/default/files/2021-01/volvo-vnr-electric-6x2-with-reefer-trailer-passenger-side-view-on-the-road-daytime-shot.png",
    },
    {
      id: 1,
      url: "https://store-images.s-microsoft.com/image/apps.3052.14235801645019276.36c222e8-fb89-4f24-8e54-cd8acb49654f.f70b2d48-863c-46c0-a44c-05ee7c55d51b?q=90&w=480&h=270",
    },
    {
      id: 2,
      url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS44c2rASZElnR_7uQUyIr0wJO_p8XLCMomEg&usqp=CAU",
    },
    {
      id: 3,
      url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAxBvQcJ9EHONsCIOv2XaAoVOlHUackCOrpw&usqp=CAU",
    },
    {
      id: 4,
      url: "https://www.renault-trucks.com/sites/corporate/files/styles/style_content_teaser/public/2021-12/Renault%20Trucks%20T%20Robust%20special%20edition_02.png?h=1072a09c&itok=M9N32dn0",
    },
  ];
  const [aciveImg, setActiveImg] = useState(0);
  const preHandler = () => {
    if (aciveImg !== 0) {
      return setActiveImg((s) => s - 1);
    }
  };
  const nextHandler = () => {
    if (aciveImg !== Images.length - 1) {
      return setActiveImg((s) => s + 1);
    }
  };
  console.log("activeImage", aciveImg);
  return (
    <div>
      <div className="position-relative ">
        <img
          src={Images[aciveImg].url}
          alt="truck"
          width="100%"
          height="100%"
        />
        <button
          type="button"
          onClick={preHandler}
          className=" cursor-pointer btn previousImg "
        >
          {" "}
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            fill="white"
            className="bi bi-chevron-left"
            viewBox="0 0 16 16"
          >
            <path
              fillRule="evenodd"
              d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"
            />
          </svg>
        </button>
        <button
          type="button"
          onClick={nextHandler}
          className="cursor-pointer btn  nextImg "
        >
          {" "}
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            fill="white"
            className="bi bi-chevron-right"
            viewBox="0 0 16 16"
          >
            <path
              fillRule="evenodd"
              d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"
            />
          </svg>
        </button>
      </div>
      <div
        className="d-flex mt-2 justify-content-between"
        style={{ overflowX: "auto" }}
      >
        {Images.map((curItem) => (
          <div
            className={`${
              curItem.id === Images[Images.length - 1].id ? "" : "me-2 "
            } ${aciveImg === curItem.id ? "acive_image" : "image_d"}`}
          >
            <img src={curItem.url} height="100%" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default CarouselView;
