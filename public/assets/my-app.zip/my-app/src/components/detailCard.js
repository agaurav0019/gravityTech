import React, { useState } from "react";
import "./detailCard.css";

const DetailCard = () => {
  const navItems = [
    { id: 0, displayName: "Overview" },
    { id: 1, displayName: "Features and Specs" },
    { id: 2, displayName: "Report" },
  ];
  const [activeTab, setActiveTab] = useState(0);
  return (
    <div className="card mt-4 mb-4 " style={{overflowX: "auto"}}>
      <div className="card-header p-0 bg-dark">
        <ul className="nav nav-pills nav-fill">
          {navItems.map((curItem) => (
            <li
              className={` m-0 nav-item ${
                activeTab === curItem.id ? "active_tab" : ""
              }`}
            >
              <a 
                className={`cursor-pointer nav-link ${
                  activeTab === curItem.id ? "active_tabli" : "tab"
                }`}
                onClick={() => setActiveTab(curItem.id)}
                aria-current="page"
              >
                {curItem.displayName}
              </a>
            </li>
          ))}
        </ul>
      </div>
      <div className="card-body">
        {activeTab === 0 && (
          <div className="p-3 ">
            <div className="row">
              <div className="text-start col-4">
                <div className="text-muted muted-text">Make Year</div>
                <div className="fs-6 fw-bold">Mar 2019</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Resistration Year</div>
                <div className="fs-6 fw-bold">Mar 2019</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Fuel Type</div>
                <div className="fs-6 fw-bold">Diesel</div>
              </div>
            </div>
            <hr></hr>
            <div className="row">
              <div className="text-start col-4">
                <div className="text-muted muted-text">KM Driven</div>
                <div className="fs-6 fw-bold">36,207 KMs</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Transmisstion Type</div>
                <div className="fs-6 fw-bold">Automatic</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">No. of Owner</div>
                <div className="fs-6 fw-bold">Second Owner</div>
              </div>
            </div>
            <hr></hr>
            <div className="row">
              <div className="text-start col-4">
                <div className="text-muted muted-text">Insurance Validity</div>
                <div className="fs-6 fw-bold">Mar 2019</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Insurance Type</div>
                <div className="fs-6 fw-bold">Comprehensive</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">RTO</div>
                <div className="fs-6 fw-bold">MH49</div>
              </div>
            </div>
          </div>
        )}
        {activeTab === 1 && (
          <div className="p-3 ">
            <div className="row">
              <div className="text-start col-4">
                <div className="text-muted muted-text">Mileage(ARAI)</div>
                <div className="fs-6 fw-bold">10.98 kmpl</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Fuel Tank Capacity</div>
                <div className="fs-6 fw-bold">80 Litres</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Power</div>
                <div className="fs-6 fw-bold">500 HP</div>
              </div>
            </div>
            <hr></hr>
            <div className="row">
              <div className="text-start col-4">
                <div className="text-muted muted-text">Max Torque</div>
                <div className="fs-6 fw-bold">700 nm</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Seating Capacity</div>
                <div className="fs-6 fw-bold">3 People</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Load Capacity</div>
                <div className="fs-6 fw-bold">25 Ton</div>
              </div>
            </div>
            <hr></hr>
            <div className="row">
              <div className="text-start col-4">
                <div className="text-muted muted-text">Cylinders</div>
                <div className="fs-6 fw-bold">6 Units</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Transmisstion </div>
                <div className="fs-6 fw-bold">6 Speed (6F+1R)</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Compilance</div>
                <div className="fs-6 fw-bold">BS6</div>
              </div>
            </div>
          </div>
        )}
        {activeTab === 2 && (
          <div className="p-3 ">
            <div className="row">
              <div className="text-start col-4">
                <div className="text-muted muted-text">Engine(51-75%)</div>
                <div className="fs-6 fw-bold">Good</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Interior</div>
                <div className="fs-6 fw-bold">Excellent</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Mechanical</div>
                <div className="fs-6 fw-bold">Avarage</div>
              </div>
            </div>
            <hr></hr>
            <div className="row">
              <div className="text-start col-4">
                <div className="text-muted muted-text">Tyre Condition</div>
                <div className="fs-6 fw-bold">Good</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Body Structure</div>
                <div className="fs-6 fw-bold">Good</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text"> Enterior</div>
                <div className="fs-6 fw-bold">Good</div>
              </div>
            </div>
            <hr></hr>
            <div className="row">
              <div className="text-start col-4">
                <div className="text-muted muted-text">Drive Train</div>
                <div className="fs-6 fw-bold">Excellent</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">Transmisstion</div>
                <div className="fs-6 fw-bold">Comprehensive</div>
              </div>
              <div className="text-start col-4">
                <div className="text-muted muted-text">RTO</div>
                <div className="fs-6 fw-bold">MH49</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DetailCard;
