import React from "react";
import "./CardComponent.css";

const CardComponent = () => {
  return (
    <div className="cardBody text-start">
      <div className="cardTitle">GET IT FINANCED</div>
      <div className="d-flex">
        <div className="cardDescription col-lg-8 col-md-8">
          <div>
            Get behind the wheel of your dream truck with our{" "}
            <span style={{ color: "#F8B301" }}>hassle-free EMI options!</span>
          </div>
          <div className="d-flex">
            <div>
              <button type="button" className="knowMoreBtn">
                Know More &gt;
              </button>
            </div>
            <div>
              <button type="button" className="contactUsBtn">
                <img src="./assests/Vector.png" alt="icon"></img>
                Contact Us
              </button>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-md-4">
          <div style={{ position: "relative" }}>
            <img
              className="img-fluid"
              style={{ position: "absolute", right: "0" }}
              src="./assests/Group.png"
              atl="group"
            ></img>
            <img
              className="img-fluid"
              style={{ position: "absolute", right: "0" }}
              src="./assests/Group1.png"
              atl="group"
            ></img>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardComponent;
